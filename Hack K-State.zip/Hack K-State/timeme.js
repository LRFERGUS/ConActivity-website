function updateDisplay() {
    const display = document.getElementById("display");
    const stopwatch = document.querySelector(".stopwatch");

    let seconds = 0;
    let minutes = 0;

    const timerInterval = setInterval(function () {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            minutes++;
        }

        display.textContent = (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;

        // Check if the timer has reached 1:00 and start/stop the flashing effect
        if (minutes === 1 && seconds === 0) {
            stopwatch.classList.toggle("red-background");
        } else {
            stopwatch.classList.remove("red-background");
        }
    }, 1000);
}

updateDisplay(); // Call it once to start the timer immediately



/* Posts */

let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}