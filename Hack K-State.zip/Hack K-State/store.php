<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="store.css">
    <title>Store</title>
</head>
<script defer src="solid.js"></script>
<script defer src="fontawesome.js"></script>
<body>
    <header class="header1">
        <h1 id="header_1">Store</h1>
        <nav class="navigation">
            <a href="index.php">Home</a>
            <a href="about.html">About</a>
            <a href="store.php">Store</a>
    </header>
</body>
<body>
    <main id="background">
        <section class="product">
            <img src= "https://www.dropbox.com/scl/fi/yqsu8qrsuw4q2ylddd0s9/e4d55769-49eb-4459-9f5a-b90893007ace.png?rlkey=n8l3twdvinro8v23obpybqz3j&raw=1" alt="Pump Up the Iron">
            <h2>Pump Up The Iron</h2>
            <p>Pumping Iron</p>
            <span class="price">50 <i class="fa-solid fa-coins fa-bounce" style="color: #000000;"></i></span>
            <button>Buy</button>
        </section>
        <section class="product">
            <img src="https://www.dropbox.com/scl/fi/qc3abaokrdeeqqffra3iw/355d4832-b74d-4a30-bbf6-aa1a05de77c4.jpg?rlkey=ok57uvs6vmzkgy8op0hr78xtr&raw=1" alt="Overachiever">
            <h2>Overachiever</h2>
            <p>Your on top of the world</p>
            <span class="price">50<i class="fa-solid fa-coins fa-bounce" style="color: #000000;"></i></span>
            <button>Buy</button>
        </section>
        <section class="product">
            <img src="https://www.dropbox.com/scl/fi/r2n0tcqy6qc36j3uqy4e5/93fdbf56-dc7e-4987-bbfd-275414ac847a.png?rlkey=w5bmmxb5e7le2op1sgm9kpgnh&raw=1" alt="Surreal Symphony">
            <h2>Surreal Symphony</h2>
            <p>This art is a surreal symphony</p>
            <span class="price">50<i class="fa-solid fa-coins fa-bounce" style="color: #000000;"></i></span>
            <button>Buy</button>
        </section>
        <section class="product">
            <img src="https://www.dropbox.com/scl/fi/0kw33g2x45f5wuauf4293/98ccbd89-bc35-4474-b9f9-c77cdc60ed96.png?rlkey=7qwy97984trcdkwbyp39s2i7l&raw=1"
                alt="Rhythmns of Revelation">
            <h2>Rhythmns of Revelation</h2>
            <p>This music sounds like rythmns of revelation</p>
            <span class="price">50<i class="fa-solid fa-coins fa-bounce" style="color: #000000;"></i></span>
            <button>Buy</button>
        </section>
    </main>
    <footer>
        &copy; 2023 ConActivity
    </footer>
</body>

</html>