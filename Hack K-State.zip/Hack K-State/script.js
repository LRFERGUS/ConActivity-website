const loginButton = document.getElementById('loginButton');
const registerLink = document.getElementById('registerLink');
const loginForm = document.querySelector('.form-box.Login');
const registerForm = document.querySelector('.form-box.Register');
const wrapper = document.querySelector('.wrapper');
const closeButton = document.getElementById('closeButton');
document.addEventListener('DOMContentLoaded', function() {
    var registerButton = document.getElementById('registerButton');
    var registerWrapper = document.querySelector('.form-box.Register');
    var buttonContainer = document.querySelector('.button-container');


loginButton.addEventListener('click', function () {
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
    wrapper.classList.add('active-popup');
});

registerLink.addEventListener('click', function () {
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
    wrapper.classList.add('active-popup');
});

closeButton.addEventListener('click', function () {
    loginForm.style.display = 'none';
    registerForm.style.display = 'none';
    wrapper.classList.remove('active-popup');
});

registerButton.addEventListener('click', function(event) {
    // Prevent the default form submission behavior (if any)
    event.preventDefault();

    // Toggle the visibility of the Register wrapper
    if (registerWrapper.style.display === 'none') {
        registerWrapper.style.display = 'block';
        buttonContainer.style.zIndex = '999'; // Bring the button to the front
    } else {
        registerWrapper.style.display = 'none';
        buttonContainer.style.zIndex = ''; // Remove the custom z-index
        }
    });
});