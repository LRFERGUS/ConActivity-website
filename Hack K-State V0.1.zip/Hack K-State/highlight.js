
function submitForm(event) {
    event.preventDefault();
    // Gather user choices and send them to the server via AJAX
    const selectedHobbies = document.querySelectorAll(".selected");
    const selectedHobbiesIds = Array.from(selectedHobbies).map(box => box.id);

    sendDataToServer(selectedHobbiesIds);
}

function sendDataToServer(selectedChoices) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "process_data.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            // Handle the response from the server if needed
            console.log(xhr.responseText);
        }
    };

    xhr.send("selectedChoices=" + selectedChoices.join(","));
}

// Your existing toggleSelection function remains the same
function toggleSelection(boxId) {
    const box = document.getElementById(boxId);

    if (box.classList.contains("selected")) {
        box.classList.remove("selected");
        box.style.backgroundColor = '';
    } else {
        const selectedBoxes = document.querySelectorAll(".selected");
        if (selectedBoxes.length < 3) {
            box.classList.add("selected");
        }
    }
}