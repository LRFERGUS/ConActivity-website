<?php

require_once 'includes/config.php';
require_once 'includes/signup_view.inc.php';

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ConActivity</title>
    <link rel="stylesheet" type="text/css" href="Design.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</head>
<body class="bg" class="loading-overlay">
    <header class="header1">
        <nav class="navigation">
            <a href="index.php">Home</a>
            <a href="about.html">About</a>
            <a href="store.php">Store</a>
        </nav>
        <button class="btnLogin-popup" id="loginButton">Login</button>
    </header>
    <div class="container">
        <div class="typed-out">Welcome to ConActivity</div>
    </div>

    <div class="wrapper">
        <div class="form-box Login">
            <span class="icon-close" id="closeButton"><ion-icon name="close"></ion-icon></span>
            <h2>Login</h2>
            <form action="#">
                <div class="input-box">
                    <span class="icon" name="mail"><ion-icon name="mail"></ion-icon></span>
                    <input type="email" required>
                    <label>Email</label>
                </div>
                <div class="input-box">
                    <span class="icon" name="lock-closed"><ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password" required>
                    <label>Password</label>
                </div>
                <div class="remember-forgot">
                    <label><input type="checkbox"> Remember me</label>
                </div>
                <div class="login-register">
                    <p>Don't have an Account? <a href="#" class="register-link" id="registerLink">Register</a></p>
                    <a href="#">Forgot Password?</a> <!-- Moved "Forgot Password" link here -->
                </div>
                <button type="submit" class="btn button">Login</button>
            </form>
        </div>
        <div class="form-box Register" style="display: none;">
            <span class="icon-close" id="closeRegister"><ion-icon name="close"></ion-icon></span> <!-- Add this line -->
            <h2>Register</h2>
            <form action="includes/regi.inc.php" method="post">
                <div class="input-box">
                    <span class="icon" name="person"><ion-icon name="person"></ion-icon></span>
                    <input type="text" name="username" required>
                    <label>Username</label>
                </div>
                <div class="input-box">
                    <span class="icon" name="mail"><ion-icon name="mail"></ion-icon></span>
                    <input type="email" name="email" required>
                    <label>Email</label>
                </div>
                <div class="input-box">
                    <span class="icon" name="lock-closed"><ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password" name="pwd" required>
                    <label>Password</label>
                </div>
                <div class="button-container">
                    <button type="submit" class="btn button" id="registerButton">Register</button>
                </div>
            </form>
        </div>        
    </div>
    <script src="script.js"></script>

    <?php
    check_signup_errors();
    ?>
</body>
</html>
