<?php
// Database connection parameters
$host = "localhost";
$username = "root"; // The default username for XAMPP
$password = ""; // The default password for XAMPP
$database = "user_choices_db"; // The name of the database you created

// Create a database connection
$mysqli = new mysqli($host, $username, $password, $database);

// Check for a successful connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// You can now perform database operations using $mysqli

// Close the database connection when done
$mysqli->close();
?>
